############################################################################
# Design Compiler Reference Methodology
# Version: B-2008.09-SP1 (Nov. 10, 2008)
# Copyright (C) 2007, 2008 Synopsys All rights reserved.
############################################################################

The reference methodology provides users with a set of reference 
scripts that serve as a good starting point for running each tool.  These 
scripts are not designed to run in their current form.  They should be used 
as a reference and adapted for use in your design environment.

The Design Compiler Reference Methodology includes options for 
running DFT Compiler and Power Compiler optimization steps.  Please note 
that additional licenses are required when running DFT Compiler and Power 
Compiler inside of Design Compiler.  The sections of the script relating to 
the use of DFT Compiler and Power Compiler are clearly marked to allow you 
to easily include or exclude these sections when preparing your synthesis 
scripts.

The Design Compiler Reference Methodology also includes scripts for top-down multivoltage 
synthesis with Unified Power Format (UPF).

For Design Compiler, a common set of scripts is provided that can be used 
to run both Design Compiler and Design Compiler Topographical.  
This common set of scripts also allows you to easily migrate your existing
scripts from wireload mode synthesis to topographical mode synthesis.
The script is designed to detect when Design Compiler is being run in
topographical mode (with the -topographical_mode option) and then
automatically executes additional steps relating to topographical mode synthesis.

The flows supported by the Design Compiler Reference Methodology include the following:

-Top-down synthesis flow including multivoltage synthesis (with UPF)
-Hierarchical synthesis flow (excluding multivoltage synthesis)

The Design Compiler Reference Methodology  also includes reference scripts for running Formality
to verify your synthesis results.


The Design Compiler Reference Methodology  includes the following files:
========================================================================

Note: All scripts are designed to work in both wireload and topographical mode.

RMsettings.txt          - Reference methodology option settings selected for
                          generating the scripts.

README.DC-RM.txt        - This file which explains how to set up and run the
                          Design Compiler Reference Methodology scripts.

Release_Notes.DC-RM.txt - Release notes for the Design Compiler Reference Methodology scripts
                          listing the incremental changes in each new version
                          of the scripts.

common_setup.tcl        - Common design setup variables for Design Compiler and
                          IC Compiler Reference Methodologies.

dc_setup.tcl            - Library setup for Design Compiler Reference Methodology 
                          (also shared by Formality script).

dc_scripts/dc.tcl       - Design Compiler Reference Methodology script for top-down synthesis or
                          block-level synthesis in a hierarchical flow.

dc_scripts/fm.tcl       - Formality script to verify top-down synthesis results or
                          block-level synthesis results in a hierarchical flow.

dc_scripts/dc_top.tcl   - Design Compiler Reference Methodology top-level integration script for
                          hierarchical flow synthesis.
                          (This file will only be included if the reference methodology scripts
                          are configured for a hierarchical flow)

dc_scripts/fm_top.tcl   - Formality top-level verification script for
                          hierarchical flow synthesis.
                          (This file will only be included if the reference methodology scripts
                          are configured for a hierarchical flow)

dc_scripts/dc.upf       - Design Compiler Reference Methodology example UPF file for top-down
                          multivoltage synthesis.
                          (This file will only be included if the reference methodology scripts
                          are configured for a multivoltage flow)


Instructions for using the Design Compiler Reference Methodology for a top-down flow:
=====================================================================================

(1)  Copy the reference methodology files to a new location.

(2)  Edit the common_setup.tcl file to set up the design name, search path, 
     and library information for your design.

(3)  Edit the dc_setup.tcl file to further customize your Design Compiler
     setup.  This file is designed to work automatically with the values provided
     in the common_setup.tcl file.

(4)  Edit the dc_scripts/dc.tcl file to customize the steps that you wish to
     perform in your design synthesis.  Read through this script carefully, note
     the comments, and choose which steps you want to include in your
     synthesis.  You may also want to change the file names to support your
     design environment.  Remember that this is a reference example and
     requires modification to work with your design.

(4a) Create or provide the UPF file to set up the multivoltage flow
     for your design.  The dc_scripts/dc.upf file shows a general example.

      Alternatively, a Tcl based utility, UPFgen, can be used to quickly generate
      a UPF template for your design.
      
      For more information about UPFgen, please see the following SolvNet article:
      https://solvnet.synopsys.com/retrieve/025029.html

(5)  Run your synthesis, using the dc.tcl script, from the same directory as
     the common_setup.tcl file:

     dc_shell -topographical_mode -f dc_scripts/dc.tcl | tee dc.log

     Note: In 2008.09, it is no longer necessary to specify -upf_mode for multivoltage
     synthesis.

(6)  Edit the dc_scripts/fm.tcl file as needed for Formality verification.

(7)  If you are using a UPF flow and you are mapping to retention registers,
     you need to replace the technology library models of those cells with
     Verilog simulation models for Formality verification.

     Please see the following SolvNet article for details:
     https://solvnet.synopsys.com/retrieve/024106.html

(8)  Run your Formality verification, using the fm.tcl script, from the same
     directory as the common_setup.tcl file:

     fm_shell -f dc_scripts/fm.tcl | tee fm.log


Instructions for using the Design Compiler Reference Methodology for a hierarchical flow:
=========================================================================================

Note: The multivoltage hierarchical flow is not yet available.
      dc_scripts/dc_MV.tcl is for top-down flow use only.

*** Important NOTE ***
###########################################################################
# Note: IC Compiler ILM support is temporarily unavailable in the
#       B-2008.09 release.  This will be resolved in a future service pack.
###########################################################################

Note: The Design Compiler Reference Methodology should be used together with the IC Compiler Hierarchical
      Reference Methodology for these steps.  The IC Compiler Hierarchical Reference Methodology is
      part of the IC Compiler Reference Methodology and is available as a separate download from SolvNet:

      IC Compiler Reference Methodology: https://solvnet.synopsys.com/retrieve/021624.html

(1) Edit the common_setup.tcl file to set up the design name, search path,
    and library information for your design.  Only the $DESIGN_NAME variable
    will change between your block-level synthesis runs.

    Note: For a hierarchical flow, the IC Compiler Hierarchical Reference Methodology requires the use of absolute paths
          in the common_setup.tcl file because this file is used at different
          UNIX path locations.

          One easy way to specify absolute paths is to use an absolute path prefix
          variable in front of your common_setup.tcl variable path
          definitions.

  Example:
        # Absolute path prefix variable
        set DESIGN_REF_DATA "/designs/ProjectX/Rev3/design_data"

        set ADDITIONAL_SEARCH_PATH "${DESIGN_REF_DATA}/rtl \
                                    ${DESIGN_REF_DATA}/libs"
        

(2) Set up separate subdirectories for each of the hierarchical blocks
    using the design name. (IC Compiler Hierarchical Reference Methodology will do this automatically)

    Ensure that each block common_setup.tcl file has DESIGN_NAME
    set to the block DESIGN_NAME (IC Compiler Hierarchical Reference Methodology will do this automatically)

    Note: Even if you use IC Compiler Hierarchical Reference Methodology to set up your block directories,
          the following files will still need to be copied in each
          block subdirectory:

    		dc_setup.tcl
    		dc_scripts/*

(3) Follow the top-down instructions above for running each of the
    hierarchical blocks using the dc_scripts/dc.tcl script.

(4) When running your block-level synthesis, include the uniquify
    section before change_names:

	set uniquify_naming_style "${DESIGN_NAME}_%s_%d"
	uniquify -force

(5) If you want to use Design Compiler Interface Logic Models (ILM),
    include the ILM creation step at the end of the script:

	create_ilm
	write -format ddc -hierarchy -output ${RESULTS_DIR}/${DESIGN_NAME}.mapped.ILM.ddc

(6) For topographical mode synthesis, include the DEF file for each block, from floorplan
    partitioning. (from IC Compiler Hierarchical Reference Methodology)

(7) Include the budgeted constraints (SDC) for each block. (from IC Compiler Hierarchical Reference Methodology)

(8) Ensure that you have DFT setup information specific for each block.
    This is not automated in the flow.  Consult with your DFT
    engineer to obtain the correct setup for each block.

    You might wish to source a block-specific DFT setup in your dc.tcl file as
    follows:

    #############################################################################
    # DFT Signal Type Definitions
    #
    # These are design-specific settings that should be modified.
    # The following are only examples and should not be used.
    #############################################################################

    source -echo -verbose ${DESIGN_NAME}.dft_signal_defs.tcl

(9) Run synthesis in each of the block subdirectories:
      cd ${BLOCK_NAME}
      dc_shell -topographical_mode -f dc_scripts/dc.tcl | tee dc.log

(10) Verify each block synthesis run separately with Formality
       cd ${BLOCK_NAME}
       fm_shell -f dc_scripts/fm.tcl | tee fm.log

(11) Verify that all of your block-level runs have completed successfully.

(12) Create an additional subdirectory for your top-level synthesis.
     (IC Compiler Hierarchical Reference Methodology will do this automatically)

(13) Edit the common_setup.tcl at the top-level.

     For each hierarchical block, you might want to add the following
     to your common_setup.tcl ${ADDITIONAL_SEARCH_PATH} at the top-level:

     ../${BLOCK_NAME}/results

     This will allow the top-level synthesis run to easily pick up the
     block-level synthesis results.

     Add any IC Compiler ILMs to the ${MW_REFERENCE_LIB_DIRS} variable. Point
     to the Milkyway design library containing the IC Compiler ILM for the abstracted block.
     

(14) Define the hierarchical block design names in the dc_setup.tcl file:

	DDC_HIER_DESIGNS - list of Design Compiler DDC hierarchical design names
	DC_ILM_HIER_DESIGNS - list of Design Compiler ILM hierarchical design names
        ICC_ILM_HIER_DESIGNS - list of IC Compiler ILM hierarchical design names

###########################################################################
# Note: IC Compiler ILM support is temporarily unavailable in the
#       B-2008.09 release.  This will be resolved in a future service pack.
###########################################################################

(15) For topographical mode synthesis, include the DEF file for the top-level.  You
     should use a floorplan where the hierarchical blocks have been
     partitioned and placed at the top-level.

     (IC Compiler Hierarchical Reference Methodology will output an updated top-level floorplan with fixed
     placement info for the hierarchical blocks)

(16) Use the same constraints at the top-level that you would use for
     a top-down flow.

(17) Run synthesis at the top-level:
	cd ${TOP_DESIGN_NAME}
	dc_shell -topographical_mode -f dc_scripts/dc_top.tcl | tee dc_top.log

(18) Verify your top-level synthesis in Formality:
	cd ${TOP_DESIGN_NAME}
	fm_shell -f dc_scripts/fm_top.tcl | tee fm_top.log

(19) The final written netlist will contain the design without the physical
     hierarchical blocks.  The next tool in the flow is expected
     to read the physical block-level synthesis results in addition to
     the top-level synthesis results to obtain the complete synthesized
     design.



Input files for the Design Compiler Reference Methodology:
==========================================================
(not all of these are required, users can change these default names)

${RTL_SOURCE_FILES} (list of RTL source files defined in dc_setup.tcl)
${DESIGN_NAME}.elab.ddc (elaborated design) if starting from GTECH
${DESIGN_NAME}.constraints.tcl (logical design constraints for synthesis) OR
${DESIGN_NAME}.sdc (SDC logical design constraints)
${DESIGN_NAME}.saif (SAIF file for gate-level power optimization)
${DESIGN_NAME}.def (DEF floorplan to use for topographical mode synthesis)
${DESIGN_NAME}.physical_constraints.tcl (physical constraints in Tcl format)

${DESIGN_NAME}.upf (Unified Power Format setup file for multivoltage flow)
${DESIGN_NAME}.set_voltage.tcl (set_voltage commands for multivoltage flow)


Output files from the Design Compiler Reference Methodology:
=============================================================
${REPORTS} directory defined in dc_setup.tcl, contains reports from the 
synthesis run.

${RESULTS} directory defined in dc_setup.tcl, contains the synthesis output 
files including the mapped netlist and files needed by for timing analysis,
power analysis, and formal verification.

The output files generated by the Design Compiler Reference Methodology 
scripts are designed to be used as inputs for the IC Compiler Reference 
Methodology.  The IC Compiler Reference Methodology is the next step in the 
reference flow and is available as a separate download from Synopsys.
